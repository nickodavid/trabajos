package com.codingdojo.proyecto.services;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.codingdojo.proyecto.models.Song;
import com.codingdojo.proyecto.repositories.LookiRepository;

@Service
public class LookiService {
    private final LookiRepository lookiRepository;

    public LookiService(LookiRepository lookiRepository) {
        this.lookiRepository = lookiRepository;
    }

    public List<Song> allSong() {
        return lookiRepository.findAll();
    }

    public void createSong(Song song) {
        lookiRepository.save(song);
    }

    public void deleteSong(Long id) {
        lookiRepository.deleteById(id);
     
    }
//    public List<Song> findTop10Songs() {
//        return lookiRepository.findTop10ByOrderByRatingDesc();
//    }
    
    

    public Song updateSong(Song updatedSong) {
        Long songId = updatedSong.getId();
        Optional<Song> optionalSong = lookiRepository.findById(songId);
        if (optionalSong.isPresent()) {
            Song existingSong = optionalSong.get();
            existingSong.setTitle(updatedSong.getTitle());
            existingSong.setArtist(updatedSong.getArtist());
            existingSong.setRating(updatedSong.getRating());
            return lookiRepository.save(existingSong);
        } else {
            throw new IllegalArgumentException("La canción con el ID " + songId + " no existe.");
        }
    }

    public Song findSong(Long id) {
        Optional<Song> optionalSong = lookiRepository.findById(id);
        return optionalSong.orElse(null);
    }
}
