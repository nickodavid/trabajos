-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Dojos`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`Dojos` ;

CREATE TABLE IF NOT EXISTS `normalizacion`.`Dojos` (
  `pk_id_dojo` INT NOT NULL,
  `Name` VARCHAR(255) NULL,
  `location` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `ipdated_at` DATETIME NULL,
  PRIMARY KEY (`pk_id_dojo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`students`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`students` ;

CREATE TABLE IF NOT EXISTS `normalizacion`.`students` (
  `pk_id_student` INT NOT NULL,
  `name` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `update_at` DATETIME NULL,
  `Dojos_pk_id_dojo` INT NOT NULL,
  PRIMARY KEY (`pk_id_student`),
  INDEX `fk_students_Dojos1_idx` (`Dojos_pk_id_dojo` ASC) VISIBLE,
  CONSTRAINT `fk_students_Dojos1`
    FOREIGN KEY (`Dojos_pk_id_dojo`)
    REFERENCES `normalizacion`.`Dojos` (`pk_id_dojo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`address`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`address` ;

CREATE TABLE IF NOT EXISTS `normalizacion`.`address` (
  `pk_id_address` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `Commune` TEXT NULL,
  `HouseNumber` INT NULL,
  `Street` TEXT NULL,
  `created_at` DATETIME NULL,
  `update_At` DATETIME NULL,
  PRIMARY KEY (`pk_id_address`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`interests`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`interests` ;

CREATE TABLE IF NOT EXISTS `normalizacion`.`interests` (
  `pk_id_interest` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `created_at` DATETIME NULL,
  `update_at` DATETIME NULL,
  PRIMARY KEY (`pk_id_interest`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`students_has_interests`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`students_has_interests` ;

CREATE TABLE IF NOT EXISTS `normalizacion`.`students_has_interests` (
  `students_pk_id` INT NOT NULL,
  `interests_fk_id_interest` INT NOT NULL,
  PRIMARY KEY (`students_pk_id`, `interests_fk_id_interest`),
  INDEX `fk_students_has_interests_interests1_idx` (`interests_fk_id_interest` ASC) VISIBLE,
  INDEX `fk_students_has_interests_students1_idx` (`students_pk_id` ASC) VISIBLE,
  CONSTRAINT `fk_students_has_interests_students1`
    FOREIGN KEY (`students_pk_id`)
    REFERENCES `normalizacion`.`students` (`pk_id_student`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_students_has_interests_interests1`
    FOREIGN KEY (`interests_fk_id_interest`)
    REFERENCES `normalizacion`.`interests` (`pk_id_interest`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`address_has_students`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`address_has_students` ;

CREATE TABLE IF NOT EXISTS `normalizacion`.`address_has_students` (
  `address_fk_id_address` INT NOT NULL,
  `students_pk_id` INT NOT NULL,
  PRIMARY KEY (`address_fk_id_address`, `students_pk_id`),
  INDEX `fk_address_has_students_students1_idx` (`students_pk_id` ASC) VISIBLE,
  INDEX `fk_address_has_students_address1_idx` (`address_fk_id_address` ASC) VISIBLE,
  CONSTRAINT `fk_address_has_students_address1`
    FOREIGN KEY (`address_fk_id_address`)
    REFERENCES `normalizacion`.`address` (`pk_id_address`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_address_has_students_students1`
    FOREIGN KEY (`students_pk_id`)
    REFERENCES `normalizacion`.`students` (`pk_id_student`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`students_has_Dojos`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`students_has_Dojos` ;

CREATE TABLE IF NOT EXISTS `mydb`.`students_has_Dojos` (
)
ENGINE = InnoDB;address


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


insert into dojos values(0, 'codingdojo' ,'lascondes' ,'23-06-22' ,'23-06-22');

select * from dojos;


