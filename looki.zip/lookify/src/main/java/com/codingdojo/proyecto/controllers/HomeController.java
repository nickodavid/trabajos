package com.codingdojo.proyecto.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.codingdojo.proyecto.models.Song;
import com.codingdojo.proyecto.services.LookiService;

import jakarta.validation.Valid;

@Controller
public class HomeController {
    private final LookiService lookiService;

    public HomeController(LookiService lookiService) {
        this.lookiService = lookiService;
    }

    @GetMapping("/")
    public String home() {
        return "index.jsp";
    }

    @RequestMapping("/dashboard")
    public String index(Model model) {
        List<Song> songs = lookiService.allSong();
        model.addAttribute("song", songs);
        return "/dashboard.jsp";
    }

    @GetMapping("/songs/new")
    public String newSong(@ModelAttribute("song") Song song) {
        return "/newSong.jsp";
    }

    @PostMapping("/song")
    public String create(@Valid @ModelAttribute("song") Song song, BindingResult result) {
        if (result.hasErrors()) {
            return "/newSong.jsp";
        } else {
            lookiService.createSong(song);
            return "redirect:/dashboard";
        }
    }

    @GetMapping("/songs/{id}")
    public String showSong(@PathVariable("id") Long id, Model model) {
        Song song = lookiService.findSong(id);
        model.addAttribute("song", song);
        return "/showSong.jsp";
    }

    @GetMapping("/songs/{id}/edit")
    public String edit(@PathVariable("id") Long id, Model model) {
        Song song = lookiService.findSong(id);
        model.addAttribute("song", song);
        return "/editSong.jsp";
    }

    @PutMapping("/songs/{id}")
    public String update(@Valid @ModelAttribute("song") Song song, BindingResult result) {
        if (result.hasErrors()) {
            return "/editSong.jsp";
        } else {
            lookiService.updateSong(song);
            return "redirect:/dashboard";
        }
    }

    @RequestMapping(value = "/songs/{id}", method = RequestMethod.DELETE)
    public String destroy(@PathVariable("id") Long id) {
        lookiService.deleteSong(id);
        return "redirect:/dashboard";
    }
}
