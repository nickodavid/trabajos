package com.codingdojo.proyecto.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.codingdojo.proyecto.models.Song;


public interface LookiRepository extends CrudRepository<Song, Long> {//aqui se coloca el nombre de la clase y el tipo de id

	List<Song> findAll();

	void deleteById(Long id);

//	List<Song> findTop10ByOrderByRatingDesc();

	
	

	

	}




