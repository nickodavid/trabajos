package com.codingdojo.proyecto.models;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
@Entity
@Table(name="song")
public class Song {
	
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    @Size(min = 5, max = 200)
	    private String Title;
	    
	    @Size(min = 5, max = 200)
	    private String Artist;
	    
	  
	    @Min(value = 1)
	    @Max(value = 10)
	    private Integer Rating;

	    

		@Column(updatable=false)
	    @DateTimeFormat(pattern="yyyy-MM-dd")
	    private Date createdAt;
	    
	    
	    @DateTimeFormat(pattern="yyyy-MM-dd")
	    private Date updatedAt;
	    
	    
	    public Song(Long id, @Size(min = 5, max = 200) String title, @Size(min = 5, max = 200) String artist,
				@Min(1) @Max(10) Integer rating, Date createdAt, Date updatedAt) {
			super();
			this.id = id;
			Title = title;
			Artist = artist;
			Rating = rating;
			this.createdAt = createdAt;
			this.updatedAt = updatedAt;
		}

		public Song() {
			super();
		}
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		public String getTitle() {
			return Title;
		}

		public void setTitle(String title) {
			Title = title;
		}

		public String getArtist() {
			return Artist;
		}
		public void setArtist(String artist) {
			Artist = artist;
		}
		public Integer getRating() {
			return Rating;
		}
		public void setRating(Integer rating) {
			Rating = rating;
		}
		public Date getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}
		public Date getUpdatedAt() {
			return updatedAt;
		}
		public void setUpdatedAt(Date updatedAt) {
			this.updatedAt = updatedAt;
		}
		@PrePersist
	    protected void onCreate() {
	        this.createdAt = new Date(System.currentTimeMillis());
	    }

	    @PreUpdate
	    protected void onUpdate() {
	        this.updatedAt = new Date(System.currentTimeMillis());
	    }
		

}
